using ShibiOMS.Domain.Entities;
using ShibiOMS.Domain.ValueObjects;
using FluentAssertions;

public class OrderTests
{
    [Fact]
    public void AddItem_ShouldAddItem_WhenValidInput()
    {
        var order = new Order(Guid.NewGuid(), Guid.NewGuid());
        Action act = () => order.Confirm();
        act.Should().Throw<InvalidOperationException>();
    }
}
