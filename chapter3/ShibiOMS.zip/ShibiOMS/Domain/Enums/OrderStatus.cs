﻿namespace ShibiOMS.Domain.Enums
{
    public enum OrderStatus
    {
        Draft,
        Confirmed,
        Shipped,
        Cancelled
    }
}