﻿using ShibiOMS.Domain.ValueObjects;

namespace ShibiOMS.Domain.Entities
{
    public class Product
    {
        public Guid Id { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public Money Price { get; private set; }

        protected Product() { }

        public Product(Guid id, string name, string description, Money price)
        {
            Id = id;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? string.Empty;
            Price = price ?? throw new ArgumentNullException(nameof(price));
        }

        public void ChangePrice(Money newPrice)
        {
            if (newPrice == null || newPrice.Amount <= 0)
                throw new ArgumentException("Price must be positive.", nameof(newPrice));
            Price = newPrice;
        }

        public void UpdateDescription(string newDescription)
        {
            Description = newDescription ?? string.Empty;
        }
    }
}
