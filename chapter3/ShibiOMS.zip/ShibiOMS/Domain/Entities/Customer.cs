﻿using ShibiOMS.Domain.ValueObjects;
using System.Net;

namespace ShibiOMS.Domain.Entities
{
    public class Customer
    {
        public Guid Id { get; private set; }
        public string Name { get; private set; }
        public Email Email { get; private set; }
        public Address Address { get; private set; }

        protected Customer() { }

        public Customer(Guid id, string name, Email email, Address address)
        {
            Id = id;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Email = email ?? throw new ArgumentNullException(nameof(email));
            Address = address ?? throw new ArgumentNullException(nameof(address));
        }

        public void ChangeAddress(Address newAddress)
        {
            if (newAddress == null)
                throw new ArgumentNullException(nameof(newAddress));
            Address = newAddress;
        }

        public void ChangeEmail(Email newEmail)
        {
            if (newEmail == null)
                throw new ArgumentNullException(nameof(newEmail));
            Email = newEmail;
        }
    }
}
