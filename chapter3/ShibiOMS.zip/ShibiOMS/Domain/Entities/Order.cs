﻿using ShibiOMS.Domain.Enums;
using ShibiOMS.Domain.ValueObjects;
using ShibiOMS.Domain.Events;

namespace ShibiOMS.Domain.Entities
{
    public class Order
    {
        public Guid Id { get; private set; }
        public Guid CustomerId { get; private set; }
        public OrderStatus Status { get; private set; }
        private readonly List<OrderItem> _items = new();
        public IReadOnlyCollection<OrderItem> Items => _items.AsReadOnly();
        public Discount Discount { get; private set; }

        private readonly List<object> _domainEvents = new();
        public IReadOnlyCollection<object> DomainEvents => _domainEvents.AsReadOnly();

        protected Order() { }

        public Order(Guid id, Guid customerId)
        {
            Id = id;
            CustomerId = customerId;
            Status = OrderStatus.Draft;
        }

        public void AddItem(Product product, int quantity, Money unitPrice)
        {
            if (Status != OrderStatus.Draft)
                throw new InvalidOperationException("Can only add items in Draft status.");

            if (product == null)
                throw new ArgumentNullException(nameof(product));

            if (quantity <= 0)
                throw new ArgumentException("Quantity must be positive.", nameof(quantity));

            if (unitPrice == null || unitPrice.Amount <= 0)
                throw new ArgumentException("Unit price must be positive.", nameof(unitPrice));

            // Enforce all items use the same currency
            if (_items.Any() && _items.First().UnitPrice.Currency != unitPrice.Currency)
                throw new InvalidOperationException("All items must be in the same currency.");

            _items.Add(new OrderItem(product.Id, product.Name, quantity, unitPrice));
        }

        public void ApplyDiscount(Discount discount)
        {
            if (discount == null)
                throw new ArgumentNullException(nameof(discount));

            if (!_items.Any())
                throw new InvalidOperationException("Cannot apply discount to an order with no items.");

            Discount = discount;
        }

        public Money CalculateTotal()
        {
            if (!_items.Any())
                return new Money(0, _items.FirstOrDefault()?.UnitPrice.Currency ?? "USD");

            decimal subtotal = _items.Sum(i => i.UnitPrice.Amount * i.Quantity);

            decimal discountAmount = 0;
            if (Discount != null)
            {
                if (Discount.Amount != null && Discount.Amount.Currency == _items.First().UnitPrice.Currency)
                    discountAmount += Discount.Amount.Amount;
                if (Discount.Percentage > 0)
                    discountAmount += subtotal * (Discount.Percentage / 100);
            }

            var total = subtotal - discountAmount;
            if (total < 0) total = 0;

            return new Money(total, _items.First().UnitPrice.Currency);
        }

        public void Confirm()
        {
            if (Status != OrderStatus.Draft)
                throw new InvalidOperationException("Only Draft orders can be confirmed.");

            if (!_items.Any())
                throw new InvalidOperationException("Cannot confirm an order without items.");

            if (CalculateTotal().Amount > 10_000)
                throw new InvalidOperationException("Order total exceeds the allowed limit.");

            Status = OrderStatus.Confirmed;
            _domainEvents.Add(new OrderConfirmedEvent(Id));
        }

        public void Cancel()
        {
            if (Status == OrderStatus.Shipped)
                throw new InvalidOperationException("Cannot cancel an order that has been shipped.");

            if (Status == OrderStatus.Cancelled)
                throw new InvalidOperationException("Order is already cancelled.");

            Status = OrderStatus.Cancelled;
            _domainEvents.Add(new OrderCancelledEvent(Id));
        }

        public void Ship()
        {
            if (Status != OrderStatus.Confirmed)
                throw new InvalidOperationException("Only confirmed orders can be shipped.");

            Status = OrderStatus.Shipped;
            // Raise domain event if needed
        }

        public void RaiseEvent(object domainEvent) => _domainEvents.Add(domainEvent);
        public void ClearDomainEvents() => _domainEvents.Clear();
    }
}
