﻿using System.Text.RegularExpressions;

namespace ShibiOMS.Domain.ValueObjects
{
    public class Email : IEquatable<Email>
    {
        public string Value { get; }

        public Email(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Email cannot be empty.", nameof(value));

            if (!Regex.IsMatch(value, @"^\S+@\S+\.\S+$"))
                throw new ArgumentException("Invalid email format.", nameof(value));

            Value = value;
        }

        public bool Equals(Email other) => other != null && Value == other.Value;
        public override bool Equals(object obj) => Equals(obj as Email);
        public override int GetHashCode() => Value.GetHashCode();
    }
}
