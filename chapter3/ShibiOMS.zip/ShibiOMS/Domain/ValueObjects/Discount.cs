﻿namespace ShibiOMS.Domain.ValueObjects
{
    public class Discount
    {
        public decimal Percentage { get; }
        public Money Amount { get; }
        public string Reason { get; }

        public Discount(decimal percentage, Money amount, string reason)
        {
            if (percentage < 0)
                throw new ArgumentException("Percentage cannot be negative.", nameof(percentage));
            if (amount != null && amount.Amount < 0)
                throw new ArgumentException("Discount amount cannot be negative.", nameof(amount));
            Percentage = percentage;
            Amount = amount;
            Reason = reason;
        }
    }
}
