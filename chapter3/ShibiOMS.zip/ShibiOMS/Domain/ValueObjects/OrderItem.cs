﻿using ShibiOMS.Domain.ValueObjects;

namespace ShibiOMS.Domain.ValueObjects
{
    public class OrderItem
    {
        public Guid ProductId { get; }
        public string ProductName { get; }
        public int Quantity { get; }
        public Money UnitPrice { get; }

        public OrderItem(Guid productId, string productName, int quantity, Money unitPrice)
        {
            if (string.IsNullOrWhiteSpace(productName))
                throw new ArgumentException("Product name is required.");

            if (quantity <= 0)
                throw new ArgumentException("Quantity must be greater than zero.");

            if (unitPrice == null || unitPrice.Amount <= 0)
                throw new ArgumentException("Unit price must be positive.");

            ProductId = productId;
            ProductName = productName;
            Quantity = quantity;
            UnitPrice = unitPrice;
        }

        public Money Subtotal() => new Money(UnitPrice.Amount * Quantity, UnitPrice.Currency);
    }
}
