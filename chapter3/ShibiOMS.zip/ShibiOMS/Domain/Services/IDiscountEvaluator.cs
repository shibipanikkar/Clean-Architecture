﻿using ShibiOMS.Domain.Entities;
using ShibiOMS.Domain.ValueObjects;

namespace ShibiOMS.Domain.Services
{
    public interface IDiscountEvaluator
    {
        Discount Evaluate(Customer customer, Order order);
    }
}
