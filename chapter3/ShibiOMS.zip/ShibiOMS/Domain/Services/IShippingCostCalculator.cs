﻿using ShibiOMS.Domain.Entities;
using ShibiOMS.Domain.ValueObjects;

namespace ShibiOMS.Domain.Services
{
    public interface IShippingCostCalculator
    {
        Money CalculateShipping(Order order, Address address);
        IReadOnlyCollection<Product> GetRecommendations(Customer customer, Product currentProduct);
    }
}
