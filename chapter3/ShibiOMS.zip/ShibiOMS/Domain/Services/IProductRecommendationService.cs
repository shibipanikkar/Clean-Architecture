﻿using ShibiOMS.Domain.Entities;

namespace ShibiOMS.Domain.Services
{
    public interface IProductRecommendationService
    {
        IReadOnlyCollection<Product> GetRecommendations(Customer customer, Product currentProduct);
    }
}