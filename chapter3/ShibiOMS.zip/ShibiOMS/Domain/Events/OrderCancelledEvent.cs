﻿namespace ShibiOMS.Domain.Events
{
    public class OrderCancelledEvent
    {
        public Guid OrderId { get; }
        public DateTime CancelledAt { get; }

        public OrderCancelledEvent(Guid orderId)
        {
            OrderId = orderId;
            CancelledAt = DateTime.UtcNow;
        }
    }
}