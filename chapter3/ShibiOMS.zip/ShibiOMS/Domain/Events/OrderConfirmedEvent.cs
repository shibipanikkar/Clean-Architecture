﻿namespace ShibiOMS.Domain.Events
{
    public class OrderConfirmedEvent
    {
        public Guid OrderId { get; }
        public DateTime ConfirmedAt { get; }

        public OrderConfirmedEvent(Guid orderId)
        {
            OrderId = orderId;
            ConfirmedAt = DateTime.UtcNow;
        }
    }
}
